#pragma once
//header files for functions
void stats()
{

	hp = 20 + hpmod; //hp is the same between all classes 


	switch (playerclassint) {
	case 1:
		attack = 5 + attackmod;
		def = 4 + defmod;
		speed = 1 + speedmod;
		break;

	case 2:
		attack = 10 + attackmod;
		def = 2 + defmod;
		speed = 3 + speedmod;
		break;

	case 3:
		attack = 10 + attackmod;
		def = 1 + defmod;
		speed = 10 + speedmod;
		break;
	}
	// checks what class is selected and gives the player the stats. also updates stats when modifyers are added
}
void statsdisplay() {

	std::cout << endl << attack << " attack";
	std::cout << endl << def << " defense";
	std::cout << endl << speed << " speed";
	std::cout << endl << hp << "hp";
	std::cout << endl << name;//displays stats after update
}
void battle(int attacke, int defe, int speede, int hpe) {

	while (hp > 0 && hpe > 0)
	{

		int dmg;
		if (speed > speede)
		{
			playerfst = true;
		}
		else if (speed < speede)
		{
			playerfst = false;


		}
		//checks who has the highest speed stat and lets them go first
		if (playerfst == true)
		{
			cout << endl << "player first";

			dmg = rand() % 5 + 1;
			hpe -= dmg + attack - defe;

			if (hpe > 0)
			{
				dmg = rand() % 5 + 1;
				hp -= dmg + attacke - defe;
			}//dmg calc order changes depending on who has highest speed stat

			cout << endl << hp << "player hp";
			cout << endl << hpe << "enemy hp";
		}
		else if (playerfst == false)
		{
			cout << endl << "enemy first";

			dmg = rand() % 5 + 1;
			hp -= dmg + attacke - def;

			if (hp > 0)
			{
				dmg = rand() % 5 + 1;
				hpe -= dmg + attack - defe;
			}


			cout << endl << hp << "player hp";
			cout << endl << hpe << "enemy hp";
			// displays hp so player can know what is happening
		}

	}
	if (hp <= 0)
	{

		cout << endl << "player loses";
		win = false;

	}
	else if (hpe <= 0)
	{
		win = true;


	}//displays if player lost or won and changes veribles 



}