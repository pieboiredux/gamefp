// gamefp.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <string>
#include <iostream>
#include <stdio.h>      
#include <stdlib.h>     
#include <time.h>
//includes time is to seed time and stdlib is for the null pointer
using namespace std; 
std::string name;
string playerclass;
int playerclassint = 5;
int attack = 0;
int def = 0; 
int speed = 0;
int hp = 20;
string choice;
bool win = true;
int attackmod = 0;
int defmod = 0; 
int speedmod = 0;
int hpmod = 0;
int gold = 200;
bool fomo = false;
bool playerfst = true;
int choiceshop;
//veribles 
#include "funcs.h" //call headder files for the functions



int main()
{
	srand(time(NULL));
	std::cout << "please enter your name" << "\n";
	std::cin >> name;
	std::cout << endl << "please enter your class your choices are knight(1),mage(2),rouge(3)";

	std::cin >> playerclass; //gets player input so they can pick there class


	if (playerclass == "1")
	{

		cout << "your player class is knight";


	}
	else if (playerclass == "2")
	{

		std::cout << "your class is mage";

	}
	else if (playerclass == "3")
	{

		cout << "your class is rouge";

	}//checks if class is right and tells the player there class
	else
	{
		cout << "please enter the number next to your player class";
		return 0;
	}//if input invlaid
	playerclassint = stoi(playerclass); //convers int to string
	cout << playerclassint;//shows choice 
	stats();//runs function form header file
	cout << endl << "your stats and name";
	statsdisplay();
	//displays stats
	cout << "You wake up in a baron wasteland covred in sand and rock." << endl << "in the middel of this waste land stands a gnome";
	cout << endl << "the gome looks up to you and smiles. ";
	cout << endl << "(gnome) O hello fair traveller welcome to my home its not much but its something" << endl << "do you want a spot of tea?";
	cout << endl << "Do you take the tea(1) or attack the gnome(2)";
	cin >> choice;//choice for game
	if (choice == "1")
	{
		cout << "you take the tea";
	}
	else if (choice == "2")
	{
		int gnome[] = { 5,1,10,15 };
		battle(gnome[0], gnome[1], gnome[2], gnome[3]);

		if (win == true)
		{
			cout << endl << "you won";
		}
		else {

			cout << endl << "you lose";
			return 0;
		}//checks if player won


	}

	if (choice == "1")
	{
		cout << endl << "you take a nice sip of tea and chat with the gnome";
		cout << endl << "the gnome lets you on your way";


	}
	else
	{

		cout << endl << "the gnome sits there dead on the floor, you dont know why you did it but you did";
		cout << endl << "on the floor you find a rune of attack(+5 attack)";
		cout << endl << "There is a note on the rune, 'to daddy love you' ";
		attackmod += 5;
	} //gives rewards if won fight
	stats();
	statsdisplay();
	cout << endl << "you walk on!";

	int pinkfellow[] = { 1,1,1,5 }; //gets stats of enemy for function

	int random = rand() % 3 + 1;
	switch (random)//gets number for random encounter 
	{
	case 1:
		cout << endl << "a pink fellow appers";
		battle(pinkfellow[0], pinkfellow[1], pinkfellow[2], pinkfellow[3]);
		if (win == true)
		{
			cout << endl << "you won";
			cout << endl << "you find the pink suit +3 all stats";
			attackmod += 3;
			defmod += 3;
			speedmod += +3;
			hpmod += 3;
		}//if 1
		else {

			cout << endl << "you lose";
			return 0;
		}
		break;
	case 2:// if 2
	{

		cout << endl << "you walk and find nothing";


		break;
	}
	case 3: {

		cout << endl << "you walk and find a fomo it looks cool but seems to give you no stat improvements";

		fomo = true;
		break;
	}// if 3

	}

	stats();
	statsdisplay();
	cout << endl << "you walk on and find a shop";
	cout << endl << "the shop keep speeks to you";
	cout << endl << "hello my names is rob do you want to look at my items (1 yes) (2 no)";
	cin >> choice;
	if (choice == "1")
	{
		for (int i = 0; i < 2; i++)
		{

			cout << endl << "i have a blasting plate(1) (+5 attack100 coins), a fomo of love(2) (+5 hp100 coins),mach bike(3) (+10 speed 200 coins)";
			cin >> choiceshop;


			switch (choiceshop)
			{
			case 1:
				if (gold >= 100)
				{
					cout << endl << "you buy the blasting plate";
					attackmod += 5;
					gold -= 100;
					cout << endl << gold;
				}
				break;


			case 2:

				if (gold >= 100)
				{
					cout << endl << "you buy the fomo of love";
					gold -= 100;
					hpmod += 5;
					cout << endl << gold;
				}
				break;


			case 3:

				if (gold >= 100)
				{
					cout << endl << "you buy the mach bike";
					gold -= 200;
					speedmod += 10;
				}
				break;// gives shop options and adds stats dependent on choice 
			}

















		}

		stats();
		statsdisplay();
		

	}
	cout << endl << "do you want to fight the shop keeper (1yes 2no)?";
	cin >> choice;
	if (choice == "1")
	{
		int rob[] = { 5,3,5,20 };
		battle(rob[0], rob[1], rob[2], rob[3]);

	}//rob boss
	if (win == true)
	{
		cout << endl << "you won";
		cout << endl << "you get all the items from the shop";
		attackmod += 5;
		speedmod += 10;
		hpmod += 5;
	}
	else {

		cout << endl << "you lose";
		return 0;
	}
	stats();
	statsdisplay();

	cout << endl << "you leave the shop";
	cout << endl << "i massive troll appears with a bunch of hot babes in hand";
	cout << endl << "out of my way dumbass i need to use the shop";
	if (fomo == true)//checks for fomo EE
	{
		cout << endl << "your fomo glows blowing the troll to bits";
		cout << endl << "you win";
		statsdisplay();
		return 0;
	}
	else
	{
		int troll[] = { 8,4,5,25 };
		battle(troll[0], troll[1], troll[2], troll[3]);
	}
	if (win == true)//fianl boss
	{
		cout << endl << "you won";
		cout << endl << "the hot babes are yours";
		statsdisplay();
		return 0;
	}
	else {

		cout << endl << "you lose";
		return 0;
	}
}
